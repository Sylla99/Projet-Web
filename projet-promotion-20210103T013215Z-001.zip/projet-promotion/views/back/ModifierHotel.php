<?php  session_start(); 
include "../../core/HotelC.php";
 if (empty($_SESSION['id']))
 {
     echo "<script type='text/javascript'>";
echo "alert('Please Login First');
window.location.href='../login.html';";
echo "</script>";
     
 }
if (isset($_GET['id'])){

    $HotelC=new HotelC();
    $result=$HotelC->recupererhotel($_GET['id']);

    foreach($result as $row){

         $image=$row->image;
           $lieu=$row->lieu;
$description=$row->description;
$date_disponible_Debut=$row->date_disponible_Debut;
$date_disponible_Fin=$row->date_disponible_Fin;
$nbr_places=$row->nbr_places;
$nom=$row->nom;
$prix=$row->prix_nuit;
    }
}
?>
<!DOCTYPE html>
<html>
  <head> 
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Dark Bootstrap Admin by Bootstrapious.com</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="all,follow">
    <!-- Bootstrap CSS-->
    <link rel="stylesheet" href="vendor/bootstrap/css/bootstrap.min.css">
    <!-- Font Awesome CSS-->
    <link rel="stylesheet" href="vendor/font-awesome/css/font-awesome.min.css">
    <!-- Custom Font Icons CSS-->
    <link rel="stylesheet" href="css/font.css">
    <!-- Google fonts - Muli-->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Muli:300,400,700">
    <!-- theme stylesheet-->
    <link rel="stylesheet" href="css/style.default.css" id="theme-stylesheet">
    <!-- Custom stylesheet - for your changes-->
    <link rel="stylesheet" href="css/custom.css">
    <!-- Favicon-->
    <link rel="shortcut icon" href="img/favicon.ico">
    <!-- Tweaks for older IEs--><!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->
  </head>
  <body>
    <header class="header">   
      <nav class="navbar navbar-expand-lg">
        <div class="search-panel">
          <div class="search-inner d-flex align-items-center justify-content-center">
            <div class="close-btn">Close <i class="fa fa-close"></i></div>
            <form id="searchForm" action="#">
              <div class="form-group">
                <input type="search" name="search" placeholder="What are you searching for...">
                <button type="submit" class="submit">Search</button>
              </div>
            </form>
          </div>
        </div>
        <div class="container-fluid d-flex align-items-center justify-content-between">
          <div class="navbar-header">
            <!-- Navbar Header--><a href="index.html" class="navbar-brand">
              <div class="brand-text brand-big visible text-uppercase"><strong class="text-primary">TourNest</strong></div>
              <div class="brand-text brand-sm"><strong class="text-primary">T</strong><strong>T</strong></div></a>
            <!-- Sidebar Toggle Btn-->
            <!-- Sidebar Toggle Btn-->
            <button class="sidebar-toggle"><i class="fa fa-long-arrow-left"></i></button>
          </div>
          <div class="right-menu list-inline no-margin-bottom">    
          
            
            <!-- Tasks-->
         
            <!-- Tasks end-->
            
            <!-- Log out -->
            <div class="list-inline-item logout">                   <a id="logout" href="../Logout.php" class="nav-link"> <span class="d-none d-sm-inline">Logout </span><i class="icon-logout"></i></a></div>
          </div>
        </div>
      </nav>
    </header>
    <div class="d-flex align-items-stretch">
      <!-- Sidebar Navigation-->
      <nav id="sidebar">
        <!-- Sidebar Header-->
        <div class="sidebar-header d-flex align-items-center">
          <div class="avatar"><img src="img/v2.png" alt="..." class="img-fluid rounded-circle"></div>
          <div class="title">
         <h1 class="h5">TourNest</h1>
          </div>
        </div>
        <!-- Sidebar Navidation Menus--><span class="heading">Main</span>
        <ul class="list-unstyled">
          <li class="active"><a href="AfficherHotel.php"> <i class="icon-home"></i>List Hotel </a></li>
          <li><a href="AfficherPromotion.php"> <i class="icon-padnote"></i>List promotion </a></li>
         
        
     
        </ul>
      </nav>
      <!-- Sidebar Navigation end-->
      <div class="page-content">
        <div class="page-header">
          <div class="container-fluid">
            <h2 class="h5 no-margin-bottom">Dashboard</h2>
          </div>
        </div>
        <section class="no-padding-top no-padding-bottom">
          <div class="container-fluid">
            <div class="row">
         
              <div class="col-md-3 col-sm-6">
                <div class="statistic-block block">
                  <div class="progress-details d-flex align-items-end justify-content-between">
                    <div class="title">
                           <div class="col mr-2">
                                           
                                       <p>Afficher Hotel </p>
                                        </div>
                                        <div class="col-auto">
                                             <a class="btn btn-primary"  href="AfficherHotel.php"><i class="fa fa-bars"> </i></a>
                            
                                        </div>
                    </div>
                   
                  </div>
                  
                </div>
              </div>
    
            </div>
          </div>
        </section>
        <section class="no-padding-bottom">
          <div class="container-fluid">
            <div class="row">
<div class="col-xl-9 col-md-6 mb-6">
                            <div class="card border-left-primary shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                           
                                                              <form  onsubmit="return validateForm()" name="myForm" method="POST" action="ModifierHotelC.php" >
                    <div class="row align-items-stretch mb-5">
                        <div class="col-md-6">
                            <div class="form-group">
                                <input class="form-control"  id="nom" name="nom" value="<?php echo $nom ?>"  type="text" placeholder="nom"   />
                  

                      </div>
                            <div class="form-group">
                                <input class="form-control"  id="lieu" name="lieu" value="<?php echo $lieu ?>"  type="text" placeholder="lieu"   />
                  
  <input type="hidden" name="id" value="<?php echo $_GET['id'] ?>">
                      </div>
                             
                            <div class="form-group form-group-textarea mb-md-0">
                                <input  class="form-control" name="description" value="<?php echo $description ?>"  id="description" placeholder="description *"  />
       
                            </div>
                            <br>
                             <div class="form-group">
                                
 <input class="form-control"  id="date_disponible_Debut" name="date_disponible_Debut" value="<?php  echo date('Y-m-d', strtotime($date_disponible_Debut)).'T'.date('H:i', strtotime($date_disponible_Debut)); ?>" type="datetime-local"   placeholder="date_disponible_Debut"   />
                            </div>
                              <div class="form-group">
                                
 <input class="form-control"  id="date_disponible_Fin" name="date_disponible_Fin" value="<?php  echo date('Y-m-d', strtotime($date_disponible_Fin)).'T'.date('H:i', strtotime($date_disponible_Fin)); ?>" type="datetime-local" placeholder="date_disponible_Fin"   />
                            </div>
                              <div class="form-group">
                                
 <input class="form-control"  id="nbr_places" name="nbr_places" value="<?php echo $nbr_places ?>" type="number" placeholder="nbr_places"   />
                            </div>
                                 <div class="form-group">
                                
 <input class="form-control"  id="prix" name="prix" value="<?php echo $prix ?>" type="number" placeholder="prix"   />
                            </div>
                                <div class="form-group">
                                
 <input class="form-control"  id="image" name="image" type="file" placeholder="image"   />
                            </div>
                        </div>
                       
                    </div>
                    <div class="text-center">
                        <div id="success"></div>
                        <button class="btn btn-primary btn-xl text-uppercase"  type="submit">Envoi</button>
                    </div>
                </form>
                <script>
                    function convertDateToUTC(date) { 
    return new Date(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate(), date.getUTCHours(), date.getUTCMinutes(), date.getUTCSeconds()); 
}
function validateForm() {
      var nom = document.forms["myForm"]["nom"].value;
  var lieu = document.forms["myForm"]["lieu"].value;
    var description = document.forms["myForm"]["description"].value;
         var nbr_places = document.forms["myForm"]["nbr_places"].value;
         var prix = document.forms["myForm"]["prix"].value;
    var image = document.forms["myForm"]["image"].value;
        var dateTimeStr = document.forms["myForm"]["date_disponible_Debut"].value;
         var dateTimeStrfin = document.forms["myForm"]["date_disponible_Fin"].value;

var date_disponible_Debut = convertDateToUTC(new Date(dateTimeStr));
var date_disponible_Fin = convertDateToUTC(new Date(dateTimeStrfin));
var now = new Date();
  if (nom == "") {
    alert("nom vide");
    return false;
  }
  if (lieu == "") {
    alert("lieu vide");
    return false;
  }
    if (description == "") {
    alert("description vide");
    return false;
  }
    if (isNaN(date_disponible_Debut.getTime()) ) {

    alert("date_disponible_Debut vide");
    return false;
  }
    if ( date_disponible_Debut < now ) {

    alert("date_disponible_Debut erreur");
    return false;
  }
 
    if (isNaN(date_disponible_Fin.getTime()) ) {

    alert("date_disponible_Fin vide");
    return false;
  }
    if ( date_disponible_Fin < now ) {

    alert("date_disponible_Debut erreur");
    return false;
  }
    if ( date_disponible_Fin <= date_disponible_Debut ) {

    alert("date_disponible_Fin doit etre sup a date_disponible_Debut");
    return false;
  }
    if (isNaN(nbr_places) ) {

    alert("nbr_places vide");
    return false;
  }
      if (prix == "" ) {

    alert("prix vide");
    return false;
  }

    if ( prix <= 0) {

    alert("prix ne doit pas etre negative");
    return false;
  }
    if ( nbr_places <= 0) {

    alert("nbr_places ne doit pas etre negative");
    return false;
  }
 
      if (image == "" ) {

    alert("image vide");
    return false;
  }

 
    
}
</script>

                                        </div>
                                   
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
            </div>
          </div>
        </section>

        
        <footer class="footer">
          <div class="footer__block block no-margin-bottom">
            <div class="container-fluid text-center">
              <!-- Please do not remove the backlink to us unless you support us at https://bootstrapious.com/donate. It is part of the license conditions. Thank you for understanding :)-->
              <p class="no-margin-bottom">2020 &copy; Design by <a href="index.html">JD&Co</a>.</p>
            </div>
          </div>
        </footer>
      </div>
    </div>
    <!-- JavaScript files-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/popper.js/umd/popper.min.js"> </script>
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>
    <script src="vendor/jquery.cookie/jquery.cookie.js"> </script>
    <script src="vendor/chart.js/Chart.min.js"></script>
    <script src="vendor/jquery-validation/jquery.validate.min.js"></script>
    <script src="js/charts-home.js"></script>
    <script src="js/front.js"></script>
  </body>
</html>