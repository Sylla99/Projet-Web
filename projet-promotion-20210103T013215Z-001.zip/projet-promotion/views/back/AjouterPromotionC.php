<?php 

include '../../entities/promation.php';
include '../../core/PromotionC.php';
include '../../core/HotelC2.php';


if(isset($_POST['val_promation'])  and isset($_POST['id_hotel']) )
{

	
$promation = new promation(0,$_POST['val_promation'],$_POST['id_hotel']);
	

	$PromotionC=new PromotionC();
	$PromotionC->ajouterpromotion($promation);
		$HotelC=new HotelC();

		$hotel = $HotelC->promoterhotel($_POST['id_hotel']);
	header('Location: AfficherHotel.php');
}
else{
	echo "verifier les champs";
}

 ?>