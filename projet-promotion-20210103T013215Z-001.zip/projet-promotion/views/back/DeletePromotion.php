<?PHP

include '../../entities/promation.php';
include '../../core/PromotionC.php';
include '../../core/HotelC2.php';


if (isset($_POST["id"]) and isset($_POST["id_Hotel"])){
	$PromotionC=new PromotionC();
	$PromotionC->Supprimerpromation($_POST["id"]);

	$HotelC=new HotelC();

		$hotel = $HotelC->deletepromoterhotel($_POST['id_Hotel']);
header('Location: AfficherPromotion.php');
}

?>