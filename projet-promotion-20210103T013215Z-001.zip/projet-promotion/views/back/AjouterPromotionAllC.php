<?php 

include '../../entities/promation.php';
include '../../core/PromotionC.php';
include '../../core/HotelC2.php';


if(isset($_POST['val_promation'])   )
{
		$HotelC=new HotelC();
$listeHotels=$HotelC->afficherlist_hotel(); 
foreach($listeHotels as $row){

	$PromotionC=new PromotionC();
if ($row['promation'] == 1)
{
	$PromotionC->Supprimerpromation_Hotel($row['id']);
}


$promation = new promation(0,$_POST['val_promation'],$row['id']);
	

	$PromotionC->ajouterpromotion($promation);

		$hotel = $HotelC->promoterhotel($row['id']);
}
	

	header('Location: AfficherHotel.php');
}
else{
	echo "verifier les champs";
}

 ?>