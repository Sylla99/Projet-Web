<?php 
/**
 * 
 */

class promation 
{

	private $id;
	private $val_promation;
	private $id_Hotel;


	
	function __construct($id,$val_promation,$id_Hotel)
	{
		$this->id=$id;
		$this->val_promation=$val_promation;
		$this->id_Hotel=$id_Hotel;
		
	}
	
	function getid(){return $this->id;}
		function getval_promation(){return $this->val_promation;}
	function getid_Hotel(){return $this->id_Hotel;}

	public function set_id($id)
		{
			$this->id = $id;
		}
			public function set_val_promation($val_promation)
		{
			$this->val_promation = $val_promation;
		}
public function set_id_Hotel($id_Hotel)
		{
			$this->id_Hotel = $id_Hotel;
		}
		
}
 ?>
