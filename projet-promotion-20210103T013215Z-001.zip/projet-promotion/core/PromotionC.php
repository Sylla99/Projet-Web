<?php

 class config {
    private static $instance = NULL;

    public static function getConnexion() {
      if (!isset(self::$instance)) {
		try{
        self::$instance = new PDO('mysql:host=localhost;dbname=promotion_db', 'root', '');
		self::$instance->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		}catch(Exception $e){
            die('Erreur: '.$e->getMessage());
		}
      }
      return self::$instance;
    }
  }

class  PromotionC{
	


	function ajouterpromotion($promotion)
	{


 	$sql="INSERT INTO `promation`(`val_promation`, `id_Hotel`) VALUES (:val_promation,:id_Hotel)";
 	$db = config::getConnexion();
 		try{
		$req=$db->prepare($sql);		
		$val_promation=$promotion->getval_promation();
		$id_Hotel=$promotion->getid_Hotel();

		$req->bindValue(':val_promation',$val_promation);
		$req->bindValue(':id_Hotel',$id_Hotel);
	
            $req->execute();
        }
        catch (Exception $e){

            echo 'Erreur: '.$e->getMessage();
        }
	}


	    function afficherlist_promation(){

		$sql="SELECT `image`, `lieu`, `description`, `date_disponible_Debut`, `date_disponible_Fin`, `nbr_places`, `nom`, `promation`, `prix_nuit` , p.id,val_promation,id_Hotel FROM `promation` p INNER JOIN hotel h WHERE h.id = p.id_Hotel";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }	
	}
function modifierpromotion($promotion,$id)
	{
 	$db = config::getConnexion();
 	$sql="UPDATE `promation` SET `val_promation`=:val_promation WHERE `id`=:id";
 		try{

        $req=$db->prepare($sql);		
	$val_promation=$promotion->getval_promation();

echo $val_promation;

		$req->bindValue(':val_promation',$val_promation);
		$req->bindValue(':id',$id);		
        $req->execute();
        }
        catch (Exception $e){

            echo 'Erreur: '.$e->getMessage();
        }
	}

        function Supprimerpromation($id){
		$sql="DELETE  from promation where  id=:id ";
		$db = config::getConnexion();
		try{
		$req=$db->prepare($sql);
			$req->bindValue(':id',$id);
 	    $req->execute();
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}
	        function Supprimerpromation_Hotel($id){
		$sql="DELETE  from promation where  id_Hotel=:id ";
		$db = config::getConnexion();
		try{
		$req=$db->prepare($sql);
			$req->bindValue(':id',$id);
 	    $req->execute();
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}
	
		function recupererhotel_promotion($id_Hotel){
		$sql="SELECT * FROM `promation` WHERE  id_Hotel=:id_Hotel ";
		$db = config::getConnexion();
		try{
		$req=$db->prepare($sql);
		$req->bindValue(':id_Hotel',$id_Hotel);
 	    $req->execute();
 		$hotel= $req->fetchALL(PDO::FETCH_OBJ);
		return $hotel;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
    }
		function recuperer_promotion($id){
		$sql="SELECT * FROM `promation` WHERE  id=:id ";
		$db = config::getConnexion();
		try{
		$req=$db->prepare($sql);
		$req->bindValue(':id',$id);
 	    $req->execute();
 		$hotel= $req->fetchALL(PDO::FETCH_OBJ);
		return $hotel;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
    }
	

		
	
}


?>